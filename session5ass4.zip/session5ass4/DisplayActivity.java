package com.example.trident.session5assignment4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by shilpa on 18/5/16.
 */
public class DisplayActivity extends Activity{
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);
        t1=(TextView)findViewById(R.id.username);
        Intent intent=getIntent();
        String txt1=intent.getStringExtra("user").toString();
        t1.setText("welcome : "+txt1);
        startActivity(intent);
    }
}
